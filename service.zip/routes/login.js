var express = require('express');
const bcrypt = require("bcryptjs");
const jwt = require('jsonwebtoken');
const auth = require("../middleware/auth");
var router = express.Router();
let db = require('../public/javascripts/db');

router.get("/mark/:LoginId",auth, async (req, res, next) => {
  const Id = req.params.LoginId;
  try {
    const userid = await db.getAllCustomer();
    res.render('mainpage', { userdata: userid});  
    return;  
  }
  catch (e) {
    console.log(e);   
  }
});
router.post("/:LoginId/mark",auth, async (req, res, next) => {
  res.send("welcome")
});



router.post("/main/:LoginId",auth, async (req, res, next) => {
  try {
    var millname = req.body.millname;
    var address = req.body.add;
    var mobno = req.body.mob_no;
    var model = req.body.modelname;

    const opticket = db.getAllAddTicket(millname, address, mobno, model);
    console.log("Save Success ");

    res.redirect("/mainpag/:LoginId");
    //res.render()

  } catch (e) {
    console.log(e);
    res.sendStatus(500);
  }




});
router.get("/table",auth, async (req, res, next) => {
  try {
    
    const userid = await db.getAllCustomer();
    console.log("table data" + userid);
    // for (let i = 0; i < userid.length; i++) {
    //     let value = userid[i].Password;
    //     console.log("user" + value)

    // if(err)throw err;
    res.render('mainpage', { userdata: userid })
    // res.status(200).json({ userName: userid});
    // console.log("password", JSON.stringify(userid))
  }
  catch (e) {
    console.log(e);
    res.sendStatus(500);
  }
});
router.post("/signout", function (req, res) {
  
  var request = req.body.LoginId;
  console.log("req"+request)
  process.env.auth = "null";
  res.redirect("/users/id");
});
module.exports = router;
