var express = require('express');
const bcrypt = require("bcryptjs");
const jwt = require('jsonwebtoken');
const fs = require("fs");
const auth = require("../middleware/auth");
var router = express.Router();
var db = require('../public/javascripts/db');

var today = new Date();
var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
var dateTime = date+' '+time;




fs.readFile('mark.json', (err, data) => {
  if (err) throw err;
  let student = JSON.parse(data);
  console.log(student);
});
router.get("/:LoginId",auth, async (req, res, next) => {
  try {
    const userid = await db.getAllCustomer();
    const userlog = await db.getOpenTicket();
    res.render('mainpage', { date:dateTime,openstate: userlog,userdata: userid,LoginId:req.params.LoginId});
     return;
  }
  catch (e) {
    console.log(e);   
  }
});

router.post("/:LoginId/update",auth, async (req, res, next) => {
  try {
    var LogInd = req.params.LoginId
    var Ticket_No = req.body.Ticket_No;
    var materials = req.body.materials;
    var Amount = req.body.Amount;
    var Do_Service = req.body.Do_Service;
    var image = req.body.myfile;
    var callstatus = "U";
    const updateTicketLogTbl = db.updateTicketLogTbl(Ticket_No, materials, Amount, callstatus,image);
    res.redirect("/users/"+LogInd);
    return;  
  }
  catch (e) {
    console.log(e);   
  }
});


router.post("/:LoginId/mark",auth, async (req, res, next) => {
  var LogInd = req.params.LoginId
  try {
    var millname = req.body.millname;
    var address = req.body.add;
    var mobno = req.body.mob_no;
    var model = req.body.modelname;
    var file = req.body.myfile
    const addTicketCustomerTbl = db.getAllAddTicketcustomerTbl(millname, address, mobno, model,file);
    const addTicketLogTbl = db.getAllAddTicketLogTbl(millname, model,date);
    console.log("Save Success ");

    res.redirect("/users/"+LogInd);
    //res.render()

  } catch (e) {
    console.log(e);
    res.sendStatus(500);
  }

});

module.exports = router;

